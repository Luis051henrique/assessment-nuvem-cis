(window.FRAMEWORKS = window.FRAMEWORKS || {})["cis-controls"] = {
  id: "cis-controls",
  nome: "CIS Controls v8.1: ambientes on-premise e híbridos (resumo)",
  grupo: "On-premise e híbrido",
  aviso: "Cada requisito resume o objetivo de um dos 18 controles do CIS Controls v8.1 (153 salvaguardas; o grupo IG1 tem 56). Os controles 13, 16 e 18 não têm salvaguardas no IG1 e entram como práticas avançadas. Os pesos são estimativa do projeto. Confira a redação e a numeração das salvaguardas na lista oficial do CIS.",
  domains: [
    { id: "INV", nome: "Inventário e configuração" },
    { id: "ACE", nome: "Dados e acesso" },
    { id: "OPS", nome: "Proteção operacional" },
    { id: "RED", nome: "Rede, e-mail e monitoramento" },
    { id: "GOV", nome: "Pessoas, terceiros e resposta a incidentes" },
    { id: "APP", nome: "Aplicações e testes (avançado)" }
  ],
  controls: [
    { id: "ONP-01", domain: "INV", w: 3, ref: "CIS Controls v8.1, controle 1", q: "Existe inventário atualizado dos ativos (servidores, estações, equipamentos de rede e dispositivos conectados), com tratamento de dispositivos não autorizados?", fix: "Montar o inventário com responsável por ativo e processo para detectar e remover ou isolar dispositivos não autorizados." },
    { id: "ONP-02", domain: "INV", w: 2, ref: "CIS Controls v8.1, controle 2", q: "Existe inventário de software, com lista de aplicações autorizadas e remoção das não autorizadas?", fix: "Inventariar os softwares, definir a lista de autorizados e remover ou justificar os demais." },
    { id: "ONP-03", domain: "INV", w: 3, ref: "CIS Controls v8.1, controle 4", q: "Servidores, estações e equipamentos de rede seguem configurações seguras padronizadas, com senhas padrão trocadas e firewall ativo nos equipamentos finais?", fix: "Definir baselines por tipo de ativo, aplicá-las de forma automatizada e revisar desvios." },
    { id: "ONP-04", domain: "ACE", w: 3, ref: "CIS Controls v8.1, controle 3", q: "Os dados são inventariados e classificados, com retenção definida, criptografia em dispositivos portáteis e descarte seguro?", fix: "Criar o inventário e a classificação de dados, definir prazos de retenção e exigir criptografia em notebooks e mídias." },
    { id: "ONP-05", domain: "ACE", w: 3, ref: "CIS Controls v8.1, controle 5", q: "Contas de usuário, administrador e de serviço são inventariadas, com senhas exclusivas, desativação de contas inativas e privilégio administrativo restrito?", fix: "Inventariar as contas, desativar as inativas, separar contas administrativas das de uso diário e proteger as senhas em cofre." },
    { id: "ONP-06", domain: "ACE", w: 3, ref: "CIS Controls v8.1, controle 6", q: "O acesso é concedido por processo formal e revogado no desligamento, com MFA para acesso remoto, aplicações expostas e contas administrativas?", fix: "Formalizar concessão e revogação de acessos e exigir MFA nos acessos externos e privilegiados." },
    { id: "ONP-07", domain: "OPS", w: 3, ref: "CIS Controls v8.1, controle 7", q: "Há gestão de vulnerabilidades e atualização (patching) de sistemas operacionais e aplicações em ciclo definido?", fix: "Definir ciclo de varredura e prazos de correção por criticidade, com relatório de pendências." },
    { id: "ONP-08", domain: "OPS", w: 3, ref: "CIS Controls v8.1, controle 8", q: "Os logs de auditoria são coletados e armazenados com capacidade e retenção definidas?", fix: "Habilitar a coleta nos sistemas críticos, centralizar o armazenamento e definir o período de retenção." },
    { id: "ONP-09", domain: "OPS", w: 3, ref: "CIS Controls v8.1, controle 10", q: "Há proteção contra malware (antimalware ou EDR) com atualização automática em servidores e estações?", fix: "Cobrir todos os ativos com a ferramenta, ativar atualização automática e acompanhar os alertas." },
    { id: "ONP-10", domain: "OPS", w: 3, ref: "CIS Controls v8.1, controle 11", q: "Há cópias de segurança automatizadas, protegidas e isoladas, com testes periódicos de restauração?", fix: "Automatizar os backups, manter uma cópia isolada da rede de produção e testar a restauração em ciclo definido." },
    { id: "ONP-11", domain: "RED", w: 2, ref: "CIS Controls v8.1, controle 9", q: "Há proteções de e-mail e navegação, como filtro de spam e anexos, filtro de URLs e navegadores e clientes de e-mail atualizados?", fix: "Ativar filtros de e-mail e de navegação e manter navegadores e clientes de e-mail em versões suportadas." },
    { id: "ONP-12", domain: "RED", w: 3, ref: "CIS Controls v8.1, controle 12", q: "A infraestrutura de rede é documentada e mantida atualizada, com firmware e software dos equipamentos em dia?", fix: "Documentar a topologia, inventariar os equipamentos e atualizar firmware e software com rotina definida." },
    { id: "ONP-13", domain: "RED", w: 2, ref: "CIS Controls v8.1, controle 13 (avançado)", q: "Há monitoramento e defesa da rede, com detecção de intrusão, filtragem de tráfego e alertas centralizados?", fix: "Implantar detecção de intrusão e centralizar os alertas de segurança em um SIEM ou serviço equivalente." },
    { id: "ONP-14", domain: "GOV", w: 2, ref: "CIS Controls v8.1, controle 14", q: "Há programa de conscientização e treinamento de segurança para todos os colaboradores, com reciclagem periódica?", fix: "Criar o programa, treinar na admissão e repetir ao menos uma vez por ano." },
    { id: "ONP-15", domain: "GOV", w: 2, ref: "CIS Controls v8.1, controle 15", q: "Os prestadores de serviço são inventariados e classificados por risco, com requisitos de segurança nos contratos?", fix: "Listar os prestadores, classificar por criticidade dos dados e acessos e incluir cláusulas de segurança." },
    { id: "ONP-16", domain: "GOV", w: 3, ref: "CIS Controls v8.1, controle 17", q: "Há processo de resposta a incidentes, com responsáveis, contatos e meios de comunicação definidos e exercícios periódicos?", fix: "Escrever o processo, definir papéis e contatos e fazer simulações em ciclo definido." },
    { id: "ONP-17", domain: "APP", w: 2, ref: "CIS Controls v8.1, controle 16 (avançado)", q: "O desenvolvimento de software segue práticas seguras, com revisão de código, testes de segurança e gestão de vulnerabilidades em código e componentes de terceiros?", fix: "Adotar um processo de desenvolvimento seguro com revisão e testes automatizados e controle de dependências." },
    { id: "ONP-18", domain: "APP", w: 2, ref: "CIS Controls v8.1, controle 18 (avançado)", q: "São feitos testes de intrusão periódicos, com correção dos achados?", fix: "Contratar ou executar testes de intrusão em ciclo definido e tratar os resultados com plano de ação." }
  ]
};
